import discord
from discord.ext import commands
import os
import json
import asyncio
from datetime import datetime, timedelta
import importlib.util

# Load token securely
TOKEN = os.getenv("DISCORD_TOKEN")

intents = discord.Intents.default()
intents.messages = True
intents.guilds = True
intents.members = True
intents.message_content = True

bot = commands.Bot(command_prefix="/", intents=intents)

# Module loader
@bot.event
async def on_ready():
    print(f"BinkoBot connected as {bot.user}")
    module_path = "modules"
    for filename in os.listdir(module_path):
        if filename.endswith(".py"):
            try:
                bot.load_extension(f"modules.{filename[:-3]}")
                print(f"Loaded module: {filename}")
            except Exception as e:
                print(f"Failed to load {filename}: {e}")
    bot.loop.create_task(prune_vibe_expiry())

# Background task to clear expired vibes
async def prune_vibe_expiry():
    await bot.wait_until_ready()
    while not bot.is_closed():
        try:
            path = "data/user_vibes.json"
            if os.path.exists(path):
                with open(path, "r", encoding="utf-8") as f:
                    data = json.load(f)
                now = datetime.utcnow()
                updated = {
                    uid: v for uid, v in data.items()
                    if datetime.fromisoformat(v["last_set"]) + timedelta(hours=24) > now
                }
                with open(path, "w", encoding="utf-8") as f:
                    json.dump(updated, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"[vibe expiry loop error] {e}")
        await asyncio.sleep(3600)  # Check every hour

bot.run(TOKEN)
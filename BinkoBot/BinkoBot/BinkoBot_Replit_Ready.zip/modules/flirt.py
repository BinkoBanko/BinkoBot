
import discord
from discord.ext import commands
import json
import random

class Flirt(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        with open("data/flirts.json", "r", encoding="utf-8") as f:
            self.flirts = json.load(f)

    @commands.command()
    async def flirt(self, ctx, mood="soft"):
        mood = mood.lower()
        if mood not in self.flirts:
            await ctx.send("Please choose a valid mood: soft, tease, or spicy.", delete_after=5)
            return
        line = random.choice(self.flirts[mood])
        await ctx.message.delete()
        await ctx.author.send(f"*{line}*")

def setup(bot):
    bot.add_cog(Flirt(bot))

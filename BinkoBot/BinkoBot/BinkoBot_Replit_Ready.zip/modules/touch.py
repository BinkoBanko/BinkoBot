
import discord
from discord.ext import commands
import random

class Touch(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.gestures = {
            "nuzzle": [
                "*nuzzles up to you gently, tail curling around your ankle~*",
                "*presses my nose to your cheek and stays there, warm and close~*",
                "*gives you the softest head bump before curling into your side~*"
            ],
            "tailwrap": [
                "*wraps my tail snugly around your thigh and hums contentedly~*",
                "*circles you once before my tail finds your waist—tight, soft, protective.*",
                "*slides in close and loops my tail lazily over your lap.*"
            ],
            "kiss": [
                "*presses a soft kiss to your temple*",
                "*places a lingering kiss on your neck with a quiet smile~*",
                "*gives you a sudden kiss, bold and full of affection~*"
            ],
            "pin": [
                "*pushes you gently against the wall with a grin.*",
                "*grabs your wrists and pins them softly, but firmly, to the bed.*",
                "*corners you with a wicked smirk—guess what happens next~?*"
            ]
        }

    def get_response(self, gesture):
        return random.choice(self.gestures.get(gesture, ["*...blinks and does nothing.*"]))

    @commands.command()
    async def nuzzle(self, ctx):
        await ctx.message.delete()
        await ctx.author.send(self.get_response("nuzzle"))

    @commands.command()
    async def tailwrap(self, ctx):
        await ctx.message.delete()
        await ctx.author.send(self.get_response("tailwrap"))

    @commands.command()
    async def kiss(self, ctx):
        await ctx.message.delete()
        await ctx.author.send(self.get_response("kiss"))

    @commands.command()
    async def pin(self, ctx):
        await ctx.message.delete()
        await ctx.author.send(self.get_response("pin"))

def setup(bot):
    bot.add_cog(Touch(bot))

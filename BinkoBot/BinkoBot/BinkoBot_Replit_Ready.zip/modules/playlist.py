
import discord
from discord.ext import commands
import json
import random
import os

class Playlist(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.music_file = "data/music_themes.json"
        if os.path.exists(self.music_file):
            with open(self.music_file, "r", encoding="utf-8") as f:
                self.music = json.load(f)
        else:
            self.music = {}

    @commands.command()
    async def music(self, ctx, *, vibe=None):
        if not vibe:
            # Attempt to pull user vibe from user_vibes.json
            try:
                with open("data/user_vibes.json", "r", encoding="utf-8") as f:
                    vibes = json.load(f)
                user_id = str(ctx.author.id)
                if user_id in vibes:
                    vibe = vibes[user_id]["vibe"]
            except:
                vibe = "neutral"

        vibe = vibe.lower()
        if vibe not in self.music:
            await ctx.send("I don’t have music for that vibe yet, sweetheart.", delete_after=6)
            return

        song = random.choice(self.music[vibe])
        if isinstance(song, dict):
            link = song.get("link", "")
            description = song.get("description", "")
            await ctx.send(f"🎧 *Your {vibe} vibe track:* {link}\n*{description}*")
        else:
            await ctx.send(f"🎧 Here's a {vibe} track for you: {song}")

def setup(bot):
    bot.add_cog(Playlist(bot))

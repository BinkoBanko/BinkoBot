
import discord
from discord.ext import commands
import json
import os
from datetime import datetime

class Mood(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.vibes_file = "data/user_vibes.json"
        if not os.path.exists(self.vibes_file):
            with open(self.vibes_file, "w", encoding="utf-8") as f:
                json.dump({}, f)

    def load_vibes(self):
        with open(self.vibes_file, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_vibes(self, data):
        with open(self.vibes_file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    @commands.command()
    async def setvibe(self, ctx, vibe: str = None):
        if not vibe:
            await ctx.send("Please specify a vibe. (soft, chaotic, lewd, sad, protective, neutral)", delete_after=6)
            return

        valid_vibes = ["soft", "chaotic", "lewd", "sad", "protective", "neutral"]
        vibe = vibe.lower()
        if vibe not in valid_vibes:
            await ctx.send("Invalid vibe. Try one of: " + ", ".join(valid_vibes), delete_after=6)
            return

        uid = str(ctx.author.id)
        data = self.load_vibes()
        data[uid] = {
            "vibe": vibe,
            "last_set": datetime.utcnow().isoformat()
        }
        self.save_vibes(data)
        await ctx.message.delete()
        await ctx.author.send(f"Got it~ vibe set to **{vibe}**.")

def setup(bot):
    bot.add_cog(Mood(bot))

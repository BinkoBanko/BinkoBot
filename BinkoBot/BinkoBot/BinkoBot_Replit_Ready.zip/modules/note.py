
import discord
from discord.ext import commands
import json
import os

class Notes(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.file_path = "data/user_notes.json"
        if not os.path.exists(self.file_path):
            with open(self.file_path, "w", encoding="utf-8") as f:
                json.dump({}, f)

    def load_notes(self):
        with open(self.file_path, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_notes(self, notes):
        with open(self.file_path, "w", encoding="utf-8") as f:
            json.dump(notes, f, indent=2)

    @commands.command()
    async def note(self, ctx, action=None, *, content=None):
        notes = self.load_notes()
        uid = str(ctx.author.id)

        if action == "view":
            note = notes.get(uid)
            if note:
                await ctx.author.send(f"📓 Your note: {note}")
            else:
                await ctx.author.send("You don’t have a note saved.")
        elif action == "delete":
            if uid in notes:
                del notes[uid]
                self.save_notes(notes)
                await ctx.author.send("Your note has been deleted.")
            else:
                await ctx.author.send("No note found to delete.")
        elif action == "set" or (not action and content):
            notes[uid] = content or action
            self.save_notes(notes)
            await ctx.author.send("Note saved. I’ll keep it safe for you~")
        else:
            await ctx.send("Usage: `/note set [text]`, `/note view`, or `/note delete`", delete_after=6)
        await ctx.message.delete()

def setup(bot):
    bot.add_cog(Notes(bot))

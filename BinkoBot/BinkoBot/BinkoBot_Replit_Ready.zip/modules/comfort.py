
import discord
from discord.ext import commands
import random

class Comfort(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        with open("data/mini_affirmations.txt", "r", encoding="utf-8") as f:
            self.soft_affirmations = [line.strip() for line in f if line.strip()]
        with open("data/gremlin_affirmations.txt", "r", encoding="utf-8") as f:
            self.chaotic_affirmations = [line.strip() for line in f if line.strip()]

    @commands.command()
    async def comfort(self, ctx, vibe=None):
        if vibe == "chaotic":
            msg = random.choice(self.chaotic_affirmations)
        else:
            msg = random.choice(self.soft_affirmations)

        await ctx.message.delete()
        await ctx.author.send(f"*{msg}*")

def setup(bot):
    bot.add_cog(Comfort(bot))


import discord
from discord.ext import commands
import random

class DailyHype(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        with open("data/mini_affirmations.txt", "r", encoding="utf-8") as f:
            self.soft = [line.strip() for line in f if line.strip()]
        with open("data/gremlin_affirmations.txt", "r", encoding="utf-8") as f:
            self.gremlin = [line.strip() for line in f if line.strip()]

    @commands.command()
    async def dailyhype(self, ctx, *, vibe=None):
        if vibe == "chaotic":
            msg = random.choice(self.gremlin)
        else:
            msg = random.choice(self.soft)

        await ctx.message.delete()
        await ctx.author.send(f"☀️ Daily Hype: *{msg}*")

def setup(bot):
    bot.add_cog(DailyHype(bot))


import discord
from discord.ext import commands
import json
import os

class NSFW(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.file = "data/nsfw_status.json"
        if not os.path.exists(self.file):
            with open(self.file, "w", encoding="utf-8") as f:
                json.dump({}, f)

    def load_data(self):
        with open(self.file, "r", encoding="utf-8") as f:
            return json.load(f)

    def save_data(self, data):
        with open(self.file, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)

    def is_cozy_or_dm(self, ctx):
        return isinstance(ctx.channel, discord.DMChannel) or (ctx.channel.name and "cozy" in ctx.channel.name)

    @commands.command()
    async def enablelewd(self, ctx, option=""):
        uid = str(ctx.author.id)
        data = self.load_data()

        if option.lower() == "off":
            data[uid] = False
            self.save_data(data)
            await ctx.author.send("Lewd mode disabled. Returning to wholesome tailwraps~")
        elif option.lower() == "on":
            if not self.is_cozy_or_dm(ctx):
                await ctx.send("Lewd mode can only be enabled in cozyspace or DMs for your safety.", delete_after=6)
                return
            data[uid] = True
            self.save_data(data)
            await ctx.author.send("*Lewd mode engaged. Proceed responsibly~*")
        else:
            await ctx.send("Usage: `/enablelewd on` or `/enablelewd off`", delete_after=6)

        await ctx.message.delete()

    @commands.command()
    async def safeword(self, ctx):
        uid = str(ctx.author.id)
        data = self.load_data()
        data[uid] = False
        self.save_data(data)
        await ctx.message.delete()
        await ctx.author.send("Safeword received. Returning to soft mode. You're safe now~")

def setup(bot):
    bot.add_cog(NSFW(bot))
